# Universal Adapter Device Test

For each visible WhatsApp instance (Personal, Business, Dual, Work Profile):
1. Enable Accessibility for WA Al-Othmany Link Bot.
2. Select the target instance.
3. Run Sync Groups.
4. Confirm the log shows the target package/profile and then either:
   - `SYNC_GROUP_FILTER_CLICKED` -> `GROUP_FILTER_VERIFIED`, or
   - conservative `ALL_CHATS_CLASSIFY` only after repeated verified misses.
5. Confirm `SYNC_COMPLETE groups=N` is close to the real group count.
6. Run Sync a second time. The adaptive selector store should reuse learned selectors and produce `ADAPTIVE_SELECTOR_VERIFIED` events.
7. Repeat on another profile; learned selectors must remain instance-scoped.

If a Secure Folder instance cannot launch or cannot expose its Accessibility tree, record that as OS/OEM blocked rather than as a successful supported instance.
