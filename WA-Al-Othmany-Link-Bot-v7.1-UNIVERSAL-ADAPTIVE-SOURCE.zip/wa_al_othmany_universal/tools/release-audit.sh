#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

bash tools/verify-core.sh

python3 tools/feature-preservation-smoke.py
python3 tools/accessibility-manifest-smoke.py
python3 tools/gesture-click-regression-smoke.py
python3 tools/v71-runtime-integration-smoke.py
python3 tools/operation-lease-integration-smoke.py
python3 tools/accessibility-state-integration-smoke.py
python3 tools/navigation-safety-integration-smoke.py
python3 tools/adaptive-selector-integration-smoke.py
python3 tools/event-coalescing-integration-smoke.py
python3 tools/async-diagnostic-log-smoke.py
python3 tools/persistence-integration-smoke.py

echo "[release] static safety audit"
python - <<'PY'
from pathlib import Path
import re
root=Path('.')
manifest=(root/'app/src/main/AndroidManifest.xml').read_text()
build=(root/'app/build.gradle.kts').read_text()
service=(root/'app/src/main/java/com/waalothmany/linkbot/automation/WaAccessibilityService.kt').read_text()
ui=(root/'app/src/main/java/com/waalothmany/linkbot/ui/AppUi.kt').read_text()
assert 'versionName = "7.1.0-rc1"' in build
assert 'versionCode = 71' in build
assert 'QUERY_ALL_PACKAGES' not in manifest
assert 'android:allowBackup="false"' in manifest
assert 'AdaptiveTimingPolicy' in service
assert 'StageCircuitBreaker' in service
assert 'SYNC_COVERAGE_SAFETY_STOP' in service
assert 'AMBIGUOUS_GROUP' in service
assert 'AutomationHealthPolicy' in service
assert 'MessageViewportPolicy' in service
assert 'ThroughputMeter' in service
assert 'ScreenKind.GROUP_LIST' in service
assert 'DurableViewportPolicy' in service
assert 'viewportCommitInFlight' in service
assert 'VIEWPORT_PERSISTENCE_FAILED' in service
assert 'SmartQueuePolicy' in service
assert 'FailureRecoveryPolicy' in service
assert 'QueueProgressPolicy' in service
assert 'SYNC_STRATEGY_SWITCH' in service
assert 'SYNC_SELECT_ALL_APPLIED' in service
assert 'ALL_CHATS_CLASSIFY' in service
assert 'SYNC_NAV_DECISION' in service
assert 'EXTRACT_NAV_DECISION' in service
assert 'LINK_PERSISTED' in service
assert 'clickTarget' in service
assert 'longClickTarget' in service
assert 'BACK_TOWARD_CHATS' in service
assert 'ExtractionSelectionPolicy' in service
assert 'UnreadTraversalPolicy' in service
assert 'findFilterControl' in service
tree=(root/'app/src/main/java/com/waalothmany/linkbot/automation/AccessibilityTree.kt').read_text()
assert 'URLSpan' in tree
assert 'screenEvidence' in tree
assert 'bestConversationScrollable' in tree
assert 'bestMessageScrollable' in tree
assert 'LazyColumn(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(4.dp)) {\n        LazyColumn' not in ui
for path in root.glob('app/src/main/java/**/*.kt'):
    text=path.read_text()
    if re.search(r'\b(?:TODO|FIXME|NotImplementedError)\b', text):
        raise AssertionError(f'placeholder marker in {path}')
# Fixed multi-second sleeps are forbidden in the automation engine. Watchdog timeout
# is allowed because it is a failure bound, not a navigation delay.
for m in re.finditer(r'delay\((\d+)\)', service):
    if int(m.group(1)) >= 1000:
        raise AssertionError(f'fixed multi-second delay in service: {m.group(0)}')
print('Static safety audit: PASS')
PY

echo "RELEASE AUDIT: PASS"
