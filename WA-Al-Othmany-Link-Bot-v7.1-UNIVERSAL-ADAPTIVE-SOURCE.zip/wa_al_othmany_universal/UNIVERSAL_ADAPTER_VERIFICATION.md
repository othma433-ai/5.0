# WA Al-Othmany Link Bot — Universal Adaptive Adapter Verification

## Implemented
- Instance-scoped adaptive selector learning.
- Package-neutral resource-id suffix matching.
- Dynamic selector hints generated from the runtime package name.
- Official Personal and Business adapters retain exact package support.
- Generic discoverable adapter can use the same stable suffixes without depending on the official package prefix.
- Learned selectors are isolated by instanceId, so Owner/Dual/Work profiles do not share learned UI state.
- Learned selector candidates are pruned after repeated verification failures.
- Lookup order: learned signature -> package-neutral suffix -> dynamic full id -> legacy id hint -> verified label/peer cluster.
- Groups/All/Chats/Select-All controls are wired into adaptive lookup.
- Groups selector is learned only after the Groups filter is verified active.
- Group-filter fallback threshold increased from 4 to 8 snapshots.
- Current Groups/All WhatsApp resource-id suffixes added for Personal, Business and generic adapters.
- Existing Deep/Unread/New extraction, Room queue, event coalescing, recovery and persistence hardening retained.

## Verification actually executed
- Core pure-Kotlin suite: PASS — 52 tests.
- Android XML parse: PASS — 5 files.
- Production-hardening source invariants: PASS.
- FeaturePreservationSmoke: PASS.
- AccessibilityManifestSmoke: PASS.
- GestureClickRegressionSmoke: PASS.
- V71RuntimeIntegrationSmoke: PASS.
- OperationLeaseIntegrationSmoke: PASS.
- AccessibilityStateIntegrationSmoke: PASS.
- NavigationSafetyIntegrationSmoke: PASS.
- AdaptiveSelectorIntegrationSmoke: PASS.
- EventCoalescingIntegrationSmoke: PASS.
- AsyncDiagnosticLogSmoke: PASS.
- PersistenceIntegrationSmoke: PASS.
- Universal static safety audit: PASS.
- git diff --check: PASS.

## Android Gradle build status
`./gradlew --version` was attempted after restoring the Gradle wrapper bootstrap files. The environment could not resolve `services.gradle.org` and curl exited with DNS error code 6 before Gradle itself started. Therefore `test`, `lint`, and `assembleDebug` are NOT claimed as executed successfully in this environment.

## Support semantics
- WhatsApp Personal: explicit adapter + adaptive fallback.
- WhatsApp Business: explicit adapter + adaptive fallback.
- Dual Messenger / Work Profile: supported when Android exposes the instance via LauncherApps/Accessibility; selector learning is isolated per instance/profile.
- Discoverable modified variants: generic structural adapter + package-neutral selectors when the package/label and accessibility tree are visible.
- Secure Folder: cannot be guaranteed on Samsung because the OS may block cross-profile/package access even for ADB-shell/Shizuku. The app must not claim a Secure Folder instance is operational until launch and Accessibility foreground verification succeed.

No Android application can honestly guarantee every modified WhatsApp build or every Secure Folder configuration because OEM/profile security boundaries can prevent discovery, launch, or Accessibility inspection. This build implements adaptive runtime behavior for every instance Android actually exposes to the app.
